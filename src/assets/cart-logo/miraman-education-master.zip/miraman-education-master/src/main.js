import Vue from 'vue'
import App from './App.vue'
import router from './router';
import store from './store'
import AppText from './components/shared-components/AppText'
import "./assets/styles/main.scss"
import './plugins/media/media-mixin'
import "./plugins/directives/click-outside"
import "./plugins/mixins/mixin"
import api from './service/apiService';
import axios from "axios/index";
import TokenService from "./service/TokenService";
import VueKatex from 'vue-katex';
import 'katex/dist/katex.min.css';
import * as veeValidate from './plugins/vee-validate/vee-validate';
import Notifications from 'vue-notification';
import velocity from 'velocity-animate'
import Loading from 'vue-loading-overlay';
import 'vue-loading-overlay/dist/vue-loading.css';
import VueMask from 'v-mask';
import Moment from 'vue-moment';
import VueMathjax from 'vue-mathjax'


Vue.config.productionTip = false;

axios.interceptors.response.use(res => res, error => {
    if (error.response && error.response.status === 401) {
        TokenService.removeToken();
        TokenService.removeRefreshToken();
        router.push({name: 'login'});
    }
    return Promise.reject(error)
});

Vue.component('AppText', AppText);
Vue.component('loading', Loading,);

Vue.config.productionTip = false;
Vue.use(VueMask);
Vue.use(Moment);
Vue.use(api);
Vue.use(Notifications, {velocity});
Vue.use(VueKatex, {
    globalOptions: {
        delimiters: [
            {left: '$$', right: '$$', display: true},
            {left: '$', right: '$', display: true},
            {left: '\\(', right: '\\)', display: true},
            {left: '\\[', right: '\\]', display: true}
        ],
        trust: true,
    }
});
Vue.use(VueMathjax);

new Vue({
    router,
    veeValidate,
    store,
    render: h => h(App),
}).$mount('#app');
