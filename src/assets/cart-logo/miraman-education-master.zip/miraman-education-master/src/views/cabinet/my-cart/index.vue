<template>
  <div class="my-cart py-30">
    <div class="container">
      <div class="section__top mb-20">
        <app-text
                :size="isMobileSmall ? 22 : isMobile ? 26 : 30"
                :line-height="isMobileSmall ? 26 : isMobile ? 30 : 36"
                weight="700"
        >
          Mening savatcham
        </app-text>
      </div>

      <div class="content">
        <div class="content__main mr-30">
          <div class="table-block">
            <table>
              <thead>
              <tr>
                <th>#</th>
                <th>Kurs nomi</th>
                <th>Ma'lumot</th>
                <th>Narhi</th>
                <th>#</th>
              </tr>
              </thead>
              <tbody>
              <tr v-for="(item, idx) in coursesListInBasket" :key="idx">
                <td>{{ idx + 1 }}</td>
                <td style="padding: 10px; width: 380px" class="d-flex align-center">
                  <div style="
                    width: 75px;
                    min-width: 75px;
                    height: 48px;
                    display: flex;
                    align-items: center;
                    margin-right: 20px">
                    <img src="/images/post.jpg" style="height: 100%;
                                 width: 100%;
                                 object-fit: cover;
                                 border-radius: 10px;
" alt="">
                  </div>

                  <AppText
                          weight="700"
                          size="14"
                          line-height="15"
                          max-lines="4"
                          style="width: 100%;"
                  >
                    {{ item.courseName }}
                  </AppText>
                </td>
                <td>
                  <AppText
                          size="12"
                          line-height="16"
                          class="color-text"
                          :title="item.courseDescription"
                  >
                    {{ item.courseDescription ? item.courseDescription.substr(0, 50) + '...' : '' }}
                  </AppText>
                </td>
                <td class="color-secondary bold-text" width="150">{{ numberFormat(item.coursePrice) }} UZS</td>
                <td style="width: 30px; padding: 10px">
                  <AppButton sides="20" theme="transparent" @click="deleteCourse(item.courseId)">
                    <img src="/icons/close-roundish.svg" alt="">
                  </AppButton>
                </td>
              </tr>
              </tbody>
            </table>
          </div>
        </div>

        <div class="sidebar">
          <div class="my-cart__details shadowed radius">
            <div class="my-cart__details-top mb-20">
              <AppText class="my-cart__details-title"
                       size="14"
                       line-height="26"
                       weight="700"
              > Umumiy narh
              </AppText>
            </div>

            <div class="my-cart__details-body">
              <AppText
                      :size="isMobileSmall ? 16 : 24"
                      :line-height="isMobileSmall ? 20 : 26"
                      weight="700"
                      class="mb-20"

              >
                {{ numberFormat(totalPrice) }} UZS
              </AppText>

              <AppButton
                      sides="20"
                      theme="secondary"
              >
                Sotib olish
              </AppButton>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>

    import "../../../assets/styles/pages/cabinet.scss"
    import AppButton from "../../../components/shared-components/AppButton";
    import {mapGetters, mapMutations} from "vuex";

    export default {
        name: "index",
        components: {AppButton},
        data() {
            return {
                coursesListInBasket: [
                    {
                        courseName: null,
                        courseDescription: null,
                        coursePrice: null,
                    }
                ],
                totalPrice: 0,
            }
        },
        computed: {
            ...mapGetters(['coursesOnBasket']),
        },
        methods: {
            ...mapMutations(['setCoursesOnBasket']),
            getCoursesInCart() {
                try {
                    this.$api.get('Main/Basket/GetAll').then(res => {
                        this.coursesListInBasket = res.result;
                        res.result.forEach(item => {
                            this.totalPrice += item.coursePrice
                        });
                    });
                } catch (e) {
                    //
                }
            },
            deleteCourse(id) {
                this.$api.delete(`main/Basket/${id}`).then(res => {
                    if (!res.error) {
                        this.getCoursesInCart();
                        let wishlist = this.coursesOnBasket;
                        wishlist.splice(wishlist.findIndex(item => parseInt(item.id) === parseInt(id)), 1);
                        this.setCoursesOnBasket(wishlist);
                    }
                });
            },
        },
        created() {
            this.getCoursesInCart();
        }
    }
</script>

<style lang="scss" scoped>

  .my-cart {
    &__details {
      border-radius: 10px;
      overflow: hidden;

      &-top {
        color: white;
        padding: 10px 30px;
        background: linear-gradient(279.37deg, #008AE4 0%, #A6DCFF 158.68%);
        text-transform: uppercase;
      }

      &-body {
        padding: 10px 30px;
      }


      &-title {
      }
    }

    .content__main {
      max-width: calc(100% - 320px);
    }

    .sidebar {
      max-width: 290px;
    }

    .table-block {
      tr {
        &:hover {
          background-color: #1594e814;
        }
      }
    }

  }

  @media (max-width: 800px) {
    .my-cart {
      .content__main {
        max-width: 100%;
        margin-right: 0;
        margin-bottom: 20px;
      }
    }
  }

</style>
