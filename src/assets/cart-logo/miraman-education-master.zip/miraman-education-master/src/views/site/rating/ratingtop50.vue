<template>
  <div class="subjects py-30">
    <div class="container">
      <div class="section__top mb-30">
        <app-text
          :size="isMobile ? 24 : 30"
          :line-height="isMobile ? 28 : 36"
          weight="700"
        >
          Konkurs natijalari
        </app-text>

      </div>
      <div class="content">
        <div class="table-block mb-30 table-hover">
          <table class="hoverTable">
            <thead>
            <tr>
              <th>#</th>
              <th>O'rni</th>
              <th>FIO</th>
              <th>O'rtacha bali</th>
              <th>Urinishlar soni</th>
              <th>To'plagan bali</th>
            </tr>
            </thead>
            <tbody>
            <tr v-for="(item, idx) in ratingList" :key="idx" class="text-center">
              <td>{{ idx + 1 }}</td>
              <td>{{ item.position }}</td>
              <td>{{ item.fullName }}</td>
              <td>{{ numberFormat(item.examBall / item.examCount) }}</td>
              <td>{{ item.examCount }}</td>
              <td>{{ item.examBall }}</td>
            </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import "../../../assets/styles/pages/cabinet.scss"

export default {
  name: "ratingtop50",
  data() {
    return {
      ratingList: [
        {
          position: 1,
          examBall: 71,
          examCount: 1,
          userId: 163,
          fullName: "Narziyev Otabek"
        }
      ]
    }
  },
  methods: {
    getRating() {
      this.$api.get('main/AbitResult/RatingTop50').then(data => {
        if (!data.error) {
          this.ratingList = data.result;
        }
      }).catch(error => {
        this.errorNotification(this.errorMes = error.response.data.error.message);
      }).finally(() => {
        console.log('im finally', this.testResults)
      })
    },
  },
  created() {
    this.getRating();
  }
}
</script>

<style scoped>

</style>
