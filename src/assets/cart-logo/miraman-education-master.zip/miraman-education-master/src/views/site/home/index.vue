<template>
  <div class="home-page">
    <HeroBanner/>

    <div class="container">

      <ScienceCategories/>

      <StudentsAreViewing/>

      <CtaBanner
        title="Har qanday narsani - Har qanday vaqtda - Har qanday joyda o'rganing"
        content="Web-saytlar va dasturlarni yaratishning har bir yo'nalishi o'ziga xos ko'nikmalar to'plamini talab qiladi. Udemy sizni zamonaviy zamonaviy, tezkor va to'liq stack veb-ishlab chiqarish amaliyoti va ko'nikmalarini tezlashtirishga yo'naltirish uchun ko'plab kurslarni taklif etadi."
        photo="/images/cta-banner.jpg"
        buttonText="Hoziroq boshlang"
      />

      <ExploreOurCourses/>

      <PopularCourses/>

      <CtaBanner
        title="Miramanda o'qiting"
        content="Dunyo bo'ylab eng yaxshi o'qituvchilar millionlab talabalarga dars berishadi. Biz sizga sevgan narsangizni o'rgatish uchun vositalar va ko'nikmalarni taqdim etamiz."
        photo="/images/cta-banner-2.png"
        buttonText="Hoziroq boshlang"
      />
      <NewCourses/>

    </div>

  </div>
</template>

<script>
import HeroBanner from "../../../components/pages/home/HeroBanner";
import CtaBanner from "../../../components/pages/home/CtaBanner";
import ScienceCategories from "../../../components/pages/home/ScienceCategories";
import StudentsAreViewing from "../../../components/pages/home/StudentsAreViewing";
import PopularCourses from "../../../components/pages/home/PopularCourses";
import NewCourses from "../../../components/pages/home/NewCourses";
import ExploreOurCourses from "../../../components/pages/home/ExploreOurCourses";

export default {
  name: "index",
  components: {
    ExploreOurCourses,
    NewCourses, PopularCourses, StudentsAreViewing, ScienceCategories, CtaBanner, HeroBanner
  },
  data() {
    return {}
  }
}
</script>

<style scoped>

</style>
