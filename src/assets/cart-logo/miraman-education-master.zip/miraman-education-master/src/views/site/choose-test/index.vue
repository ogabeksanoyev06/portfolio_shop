<template>
  <div class="container">
    <section class="section choose-test py-40">
      <div class="section__top mb-30">
        <div class="section__top-left">
          <app-text
              :size="isMobileSmall ? 22 : isMobile ? 26 : 30"
              :line-height="isMobileSmall ? 26 : isMobile ? 30 : 36"
              weight="700"
              class="mb-10"
          >
            Abiturientlar va o'quvchilar uchun test topshirish tizimi
          </app-text>

          <app-text
              :size="isMobileSmall ? 12 : 14"
              :line-height="isMobileSmall ? 16 : 26"
              weight="500"
          >
            DTM talablari asosida tuzilgan 40 000 ta test savollaridan foydalangan holda test topshirish imkoni
          </app-text>
        </div>
      </div>

      <BlockWrap :count="isMobileSmall ? 1 : isMobile ? 2 : 3"
                 :offset-y="isMobileSmall ? 15 : 20"
                 :offset-x="isMobileSmall ? 15 : 20"
      >
        <div class="block__item bordered"
             :class="isMobileSmall ? 'pa-15' : 'pa-30'"
        >

          <BlockWrap count="2"
                     width-auto
                     class="align-center mb-20"
          >
            <div class="block__icon">
              <img src="/svg/online-exams.svg" alt="icon">
            </div>

            <app-text size="18"
                      line-height="24"
                      weight="700"
            >Onlayn testlar
            </app-text>

          </BlockWrap>

          <AppText
              size="14"
              line-height="20"
              class="color-text mb-20"
          >
            Siz ushbu bo'limda qabul test tizimi talablari asosida onlayn imtihon topshirasiz.
            Test varianti DTM talablari asosida shakllantirilgan.
            Savollar 40 000 savol ichidan tanlab beriladi.
            Testni boshlash uchun boshlash tugmachasini bosing
          </AppText>

          <AppButton
              @click="chooseTestModal = true"
              theme="secondary"
              sides="20"
              :font-size="isMobileSmall ? 14 : 16"
              :height="isMobileSmall ? 40 : 50"
          >
            Testni boshlash
          </AppButton>
        </div>
        <div class="block__item bordered" :class="isMobileSmall ? 'pa-15' : 'pa-30'">
          <BlockWrap count="2"
                     width-auto
                     class="align-center mb-20"
          >
            <div class="block__icon">
              <img src="/svg/block-exams.svg" alt="icon">
            </div>

            <app-text size="18"
                      line-height="24"
                      weight="700"
            >Blokli testlar
            </app-text>

          </BlockWrap>

          <AppText
              size="14"
              line-height="20"
              class="color-text mb-20"

          >
            Bu qismda tanlagan faningiz bo'yicha 30 ta savoldan iborat testlarni yechasiz.
            10 marta blokli test topshirish tekin.
            Testni boshlash uchun
            boshlash tugmachasini bosing
          </AppText>

          <AppButton
              @click="startBlockTest"
              theme="secondary"
              sides="20"
              :font-size="isMobileSmall ? 14 : 16"
              :height="isMobileSmall ? 40 : 50"
          >
            Testni boshlash

          </AppButton>

        </div>

        <div class="block__item bordered"
             :class="isMobileSmall ? 'pa-15' : 'pa-30'"
        >

          <BlockWrap count="2"
                     width-auto
                     class="align-center mb-20"
          >
            <div class="block__icon">
              <img src="/svg/school-exams.svg" alt="icon">
            </div>

            <app-text size="18" line-height="24" weight="700">Maktab o'quvchilari uchun</app-text>

          </BlockWrap>

          <AppText
              size="14"
              line-height="20"
              class="color-text mb-20"

          >
            Ushbu bo'limda maktab o'quvchilari uchun tanlangan fan va undagi mavzular ro'yxatidan bir nechta mavzuni
            tanlab olish va ular asosida ko'rsatilgan sondagi testlarni yechish imkoniga ega bo'lasiz.
          </AppText>

          <AppButton
              @click="startClassTest"
              theme="secondary"
              sides="20"
              :font-size="isMobileSmall ? 14 : 16"
              :height="isMobileSmall ? 40 : 50"
          >
            Testni boshlash
          </AppButton>

        </div>

      </BlockWrap>


      <AppModal v-if="chooseTestModal" v-model="chooseTestModal" class="modal-sm" @close="closeModal">
        <div class="modal__wrap"
             :class="isMobileSmall ? 'pa-20' : 'pa-30'"
        >
          <div class="modal__body">

            <div class="radius mb-20">
              <BaseSelect placeholder="Yo'nalishni tanlang" :options-prop="specList" v-model="selectedDirection"
                          @change="directionChange"/>
            </div>

            <div class="greyBg pa-10 radius mb-20">
              <AppText
                  size="14"
                  line-height="24"
                  weight="700"
              >
                Majburiy fanlar:
              </AppText>
            </div>

            <BlockWrap
                :count="isMobileSmall ? 1 : 2 "
                offset-y="10"
                class="align-center mb-10"
                v-for="(item, index) in directionMandatorySubjects"
                :key="index + 'mandatory'">
              <AppText
                  size="14"
                  line-height="24"
                  weight="700"
              >{{ subjectLabels[index] }}
              </AppText>
              <BaseSelect placeholder="Fanni tanlang"
                          :options-prop="item.subjects"
                          v-if="item && item.subjects && item.subjects.length > 0"
                          v-model="item.selectedSubjectId"
              />
            </BlockWrap>

            <BlockWrap v-if="directionMandatorySubjects.length <= 0"
                       :count="isMobileSmall ? 1 : 2 "
                       offset-y="10"
                       class="align-center mb-10">
              <AppText
                  size="14"
                  line-height="24"
                  weight="700"
              >Birinchi fan
              </AppText>
              <BaseSelect placeholder="Fanni tanlang" disabled/>
            </BlockWrap>

            <BlockWrap v-if="directionMandatorySubjects.length <= 0"
                       :count="isMobileSmall ? 1 : 2 "
                       offset-y="10"
                       class="align-center mb-10">
              <AppText
                  size="14"
                  line-height="24"
                  weight="700"
              >Ikkinchi fan
              </AppText>
              <BaseSelect placeholder="Fanni tanlang" disabled/>
            </BlockWrap>

            <BlockWrap v-if="directionMandatorySubjects.length <= 0"
                       :count="isMobileSmall ? 1 : 2 "
                       offset-y="10"
                       class="align-center mb-10">
              <AppText
                  size="14"
                  line-height="24"
                  weight="700"
              >Uchinchi fan
              </AppText>
              <BaseSelect placeholder="Fanni tanlang" disabled/>
            </BlockWrap>

            <div class="greyBg pa-10 radius mb-20 mt-20">
              <AppText
                  size="14"
                  line-height="24"
                  weight="700"
              >
                Asosiy fanlar
              </AppText>
            </div>

            <BlockWrap class="align-center mb-10"
                       :count="isMobileSmall ? 1 : 2 "
                       offset-y="10"
                       v-for="(item, index) in directionMainSubjects"
                       :key="index"
            >
              <AppText
                  size="14"
                  line-height="24"
                  weight="700"
              >{{ subjectLabels[index] }}
              </AppText>
              <BaseSelect placeholder="Fanni tanlang" :options-prop="item.subjects" v-model="item.selectedSubjectId"/>
            </BlockWrap>

            <BlockWrap class="align-center mb-10"
                       :count="isMobileSmall ? 1 : 2 "
                       offset-y="10"
                       v-if="directionMainSubjects.length <= 0"
            >
              <AppText
                  size="14"
                  line-height="24"
                  weight="700"
              >Birinchi fan
              </AppText>
              <BaseSelect placeholder="Fanni tanlang" disabled/>
            </BlockWrap>

            <BlockWrap class="align-center mb-10"
                       :count="isMobileSmall ? 1 : 2 "
                       offset-y="10"
                       v-if="directionMainSubjects.length <= 0"
            >
              <AppText
                  size="14"
                  line-height="24"
                  weight="700"
              >Ikkinchi fan
              </AppText>
              <BaseSelect placeholder="Fanni tanlang" disabled/>
            </BlockWrap>

            <BlockWrap
                :count="isMobileSmall ? 1 : 2"
                offset-y="10"
                offset-x="20"
                width-auto
            >

              <AppText
                  size="14"
                  line-height="24"
                  weight="700"
              >
                Umumiy vaqti:
              </AppText>
              <AppText
                  size="16"
                  line-height="24"
                  weight="700"
                  class="color-secondary"
              >
                {{ currencyFormat(examsOverAllTime) }} min
              </AppText>


            </BlockWrap>

            <BlockWrap
                :count="isMobileSmall ? 1 : 2"
                offset-y="10"
                offset-x="20"
                width-auto
                class="mb-20"
            >

              <AppText
                  size="14"
                  line-height="24"
                  weight="700"
              >
                Maksimum ball:
              </AppText>

              <AppText
                  size="16"
                  line-height="24"
                  weight="700"
                  class="color-main"
              >
                {{ currencyFormat(examsOverAllBall) }} ball
              </AppText>

            </BlockWrap>

            <AppButton
                theme="secondary"
                @click="startOnlineTest"
                sides="20"
                :font-size="isMobileSmall ? 14 : 16"
                :height="isMobileSmall ? 40 : 50"
                style="width: 100%;"
                :disabled="startTestButtonState"
            >
              Testni boshlash

            </AppButton>

          </div>

        </div>
      </AppModal>

    </section>
  </div>
</template>

<script>
import BlockWrap from "../../../components/shared-components/BlockWrap";
import AppButton from "../../../components/shared-components/AppButton";
import AppModal from "../../../components/shared-components/AppModal";
import BaseSelect from "../../../components/shared-components/BaseSelect";
import {mapActions, mapGetters, mapMutations} from "vuex";
import test from "../../../constants/test";

export default {
  name: "index",
  components: {BaseSelect, AppModal, AppButton, BlockWrap},
  data() {
    return {
      chooseTestModal: false,
      selectedDirection: null,
      directionMandatorySubjects: [],
      directionMainSubjects: [],
      subjectLabels: [
        'Birinchi fan',
        'Ikkinchi fan',
        'Uchinchi fan',
      ],
      examsOverAllTime: 0,
      examsOverAllBall: 0,
      subjectsListForStartingTest: [],
      selectedSubjectsForOnlineTest: [],
      firstSubjectId: null,
      startTestButtonState: true,
    }
  },
  computed: {
    ...mapGetters(['specList']),
  },
  methods: {
    ...mapActions(['getSpecList']),
    ...mapMutations(['setTestType']),
    directionChange() {
      if (!this.selectedDirection) {
        this.startTestButtonState = true;
        this.directionMainSubjects = [];
        this.directionMandatorySubjects = [];
        this.examsOverAllTime = 0;
        this.examsOverAllBall = 0;
        return;
      }
      this.getSubjectsByDirectionId(this.selectedDirection);
    },
    getSubjectsByDirectionId(directionId) {
      try {
        this.$api.get('main/ExamTest/GetExam?specId=' + directionId).then(res => {
          if (!res.error) {
            this.directionMainSubjects = [];
            this.directionMandatorySubjects = [];
            this.examsOverAllTime = 0;
            this.examsOverAllBall = 0;
            res.result.forEach((item, key) => {

              let model = {};
              model.examId = item.examId;
              model.selectedSubjectId = key === 0 ? item.subjects[0].id : null;
              item.selectedSubjectId = item.subjects[0].id;

              this.subjectsListForStartingTest.push(model);
              if (key <= 2) {
                this.directionMandatorySubjects.push(item);
              } else {
                this.directionMainSubjects.push(item);
              }
              this.examsOverAllBall += item.quesCount * item.quesBall;
              this.examsOverAllTime += item.testMinute;
            });
          }
          this.startTestButtonState = false;
        })
      } catch (e) {
        console.log('error ont getSubjectsByDirectionId' + e)
      }
    },
    defaultChange() {
      console.log('im here')
    },
    startOnlineTest() {
      this.clearTestPropertiesFromLocalStorage();
      this.storeTestTimeToStorage(this.examsOverAllTime);
      this.directionMandatorySubjects.forEach(s => {
        let model = {
          examId: s.examId,
          subjectId: parseInt(s.selectedSubjectId)
        }
        this.selectedSubjectsForOnlineTest.push(model);
      })

      this.directionMainSubjects.forEach(s => {
        let model = {
          examId: s.examId,
          subjectId: parseInt(s.selectedSubjectId)
        }
        this.selectedSubjectsForOnlineTest.push(model);
      })
      this.setTestType(test.TYPE_ONLINE);
      this.setTestTypeToStorage(test.TYPE_ONLINE);
      try {
        this.$api.post('main/ExamTest/GoTest', this.selectedSubjectsForOnlineTest).then(res => {
          if (!res.error) {
            localStorage.setItem('questions', JSON.stringify(res.result));
            this.$router.push('test');
          }
        }).catch(err => {
          this.errorNotification(err.response.data.error.message);
        })
      } catch (e) {
        this.errorNotification('Hatolik yuz berdi!');
      }
    },
    startBlockTest() {
      this.clearTestPropertiesFromLocalStorage();
      this.$router.push({path: '/choose-subject'});
    },
    startClassTest() {
      this.clearTestPropertiesFromLocalStorage();
      this.$router.push({path: '/choose-subject-school'});
    },
    closeModal() {
      this.chooseTestModal = false;
    },
  },
  created() {
    this.removeTestAttributesFromStorage();
    this.getSpecList();
  }
}
</script>

<style scoped>

</style>
