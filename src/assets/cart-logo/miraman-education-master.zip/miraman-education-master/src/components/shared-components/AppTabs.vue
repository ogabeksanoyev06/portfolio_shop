<template>

</template>

<script>
  export default {
    name: "AppTabs",
  }
</script>

<style scoped>

</style>
