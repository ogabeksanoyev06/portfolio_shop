<template>
  <section class="section py-40">

    <div class="section__top mb-30">
      <app-text
        :size="isMobile ? 24 : 30"
        :line-height="isMobile ? 28 : 36"
        weight="700"
      >
        Bizning kurslarimizni o'rganing
      </app-text>
    </div>

    <div class="tab__main">
      <div class="section__top">
        <div class="section__top-left">
          <div class="tab">
            <button class="tab__item" v-for="(subject, index) in subjectTree"
                    @click="selectSubject(subject.id)"
                    :key="index"
                    :class="homePageCoursesSubjectId === subject.id ? 'active' : ''">
              {{ subject.name }}
            </button>
          </div>
        </div>
        <!-- <div class="section__top-details">
           <router-link to="/" class="section__top-link pa-20">Barchasi</router-link>
         </div>-->
      </div>
      <div class="tab__body">
        <AppText
          size="16"
          line-height="20"
          weight="500"
          class="mb-30 color-text"

        >
          Veb-saytlar va dasturlarni yaratishning har bir yo'nalishi o'ziga xos ko'nikmalar to'plamini talab qiladi.
          Sizni zamonaviy zamonaviy, tezkor va to'liq stack veb-ishlab chiqarish amaliyoti va ko'nikmalarini
          tezlashtirishga yo'naltirish uchun ko'plab kurslarni taklif etamiz.
        </AppText>

        <AppText v-if="courseNotFound"
                 size="18"
                 line-height="20"
                 weight="500"
                 class="mb-30 color-text"

        >
          Tanlangan fan bo'yicha kurs mavjud emas!
        </AppText>

        <loading
          :active="loading"
          :can-cancel="true"
          :color="'#fda82b'"
          :height="50"
          :is-full-page="true"
          :loader="'dots'"
          :opacity="0.3"
          :transition="''"
          :width="70"
        ></loading>

        <AppSlider :list="list">

          <template #default="{item, medium}">
            <AppCard
              :link="item.link"
              :title="item.title"
              :subtitle="item.subtitle"
              :photo="item.photo"
              :medium="medium"
              :id="item.id"
              :value="item.value"
              :price="item.price"
            />
          </template>

        </AppSlider>


      </div>
    </div>

  </section>
</template>

<script>

import AppSlider from "../../shared-components/AppSlider";
import AppCard from "../../shared-components/AppCard";
import {mapActions, mapGetters, mapMutations} from "vuex";

export default {
  name: "ExploreOurCourses",
  components: {
    AppCard,
    AppSlider,
  },
  data() {
    return {
      list: [],
      courseNotFound: false,
    }
  },
  computed: {
    ...mapGetters(['subjectTree', 'homePageCoursesSubjectId', 'coursesBySubjectId', 'loading']),
  },
  methods: {
    ...mapActions(['getSubjectTree', 'getCoursesBySubjectId']),
    ...mapMutations(['setHomePageCoursesSubjectId']),
    setSubjectId() {
      if (this.subjectTree && this.subjectTree[0]) {
        this.selectSubject(this.subjectTree[0].id)
      }
    },
    async selectSubject(subjectId) {
      await this.getCoursesBySubjectId(subjectId)
      this.setHomePageCoursesSubjectId(subjectId);
    },
    async prepareCoursesBySubjectId() {
      this.courseNotFound = false;
      this.list = [];
      if (!this.coursesBySubjectId || this.coursesBySubjectId.length <= 0) {
        this.courseNotFound = true;
        return;
      }
      this.coursesBySubjectId.forEach(c => {
        let courseModel = {
          title: c.name.substr(0, 50) + '...',
          subtitle: c.description,
          photo: c && c.pictureLarge ? this.baseURL + '/' + c.pictureLarge : '/images/post.jpg',
          value: 1,
          price: this.currencyFormat(c.price) + " so'm",
          id: c.id,
          link: window.location.href + '' + 'detailed-page/' + c.id
        }
        this.list.push(courseModel);
      })
    }
  },
  mounted() {
    this.setSubjectId();
  },
  watch: {
    subjectTree() {
      this.setSubjectId();
    },
    coursesBySubjectId() {
      this.prepareCoursesBySubjectId();
    }
  }
}
</script>

<style lang="scss">

@import "../../../assets/styles/abstracts/variables";

.explore-our-courses {
}

.tab__main {
  border: 1px solid $border-color;
  border-radius: 16px;
  overflow: hidden;
  width: 100%;

  .tab {
    display: flex;
    align-items: center;
    flex-wrap: wrap;
    justify-content: center;

    &__item {
      padding: 20px 0;
      margin: 0 15px;
      font-weight: 600;
      font-size: 16px;
      line-height: 26px;
      color: $color-text;
      cursor: pointer;
      background-color: transparent;
      width: max-content;
      white-space: nowrap;
      padding-right: 30px;

      &.active {
        color: $text-color-default;
        border-bottom: 2px solid $color-main;
      }
    }

    &__body {
      padding: 0 20px 20px;
      border-top: 1px solid $border-color;
      padding-top: 30px;
    }
  }

  .app-slider {
    &__button {
      &-previous {
        left: -15px !important;
      }

      &-next {
        right: -15px !important;
      }
    }

  }
}


@media (max-width: 1140px) {

  .tab__main {
    .tab__item {
      font-size: 14px;
      padding: 10px 0;
    }
  }

  .section__top {
    padding: 10px;
    justify-content: center;
    text-align: center;

    .section__top-details {
      margin: auto;
      margin-bottom: 20px;
    }
  }

}

@media (max-width: 400px) {
  .tab__main {
    .tab__item {
      width: 100%;
    }
  }

  .section__top-details {
    margin-top: 20px !important;
  }
}


</style>
