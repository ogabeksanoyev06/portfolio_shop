<template>
  <section class="section py-40">

    <div class="section__top mb-30">
      <app-text
          :size="isMobile ? 24 : 30"
          :line-height="isMobile ? 28 : 36"
          weight="700"
      >
        Tavsiya etilgan kurslar
      </app-text>

      <div class="section__top-details">
        <router-link class="section__top-link" to="/">
          Barchasi
        </router-link>
      </div>
    </div>

    <app-slider :list="list">
      <template #default="{item, medium}">
        <AppCard
            :link="item.link"
            :title="item.title"
            :subtitle="item.subtitle"
            :photo="item.photo"
            :medium="medium"
            :id="item.id"
            :value="item.value"
            :price="item.price"
        />
      </template>

    </app-slider>
  </section>
</template>

<script>
import AppSlider from "../../shared-components/AppSlider";
import AppCard from "../../shared-components/AppCard";

export default {
  name: "StudentsAreViewing",
  components: {AppCard, AppSlider},
  data() {
    return {
      list: [
        {
          title: "The Web Developer Bootcamp 2021",
          subtitle: "COMPLETELY REDONE - The only course you need to learn web development - HTML, CSS, JS, Node, and More!",
          photo: "/images/post.jpg",
          value: "2",
          price: "700 000 so'm"
        },
        {
          title: "The Web Developer Bootcamp 2021",
          subtitle: "COMPLETELY REDONE - The only course you need to learn web development - HTML, CSS, JS, Node, and More!",
          photo: "/images/post.jpg",
          value: "2",
          price: "700 000 so'm"
        },
        {
          title: "The Web Developer Bootcamp 2021",
          subtitle: "COMPLETELY REDONE - The only course you need to learn web development - HTML, CSS, JS, Node, and More!",
          photo: "/images/post.jpg",
          value: "2",
          price: "700 000 so'm"
        },
        {
          title: "The Web Developer Bootcamp 2021",
          subtitle: "COMPLETELY REDONE - The only course you need to learn web development - HTML, CSS, JS, Node, and More!",
          photo: "/images/post.jpg",
          value: "2",
          price: "700 000 so'm"
        },
        {
          title: "The Web Developer Bootcamp 2021",
          subtitle: "COMPLETELY REDONE - The only course you need to learn web development - HTML, CSS, JS, Node, and More!",
          photo: "/images/post.jpg",
          value: "2",
          price: "700 000 so'm"
        }
      ]
    }
  },
  methods: {
    getTopCourses() {
      this.$api.get('Main/Course/GetTopCourseAll').then(res => {
        if (!res.error) {
          this.popularCourses = res.result;
          this.popularCourses.sort((a, b) => (a.displayOrder > b.displayOrder) ? 1 : -1)
          this.list = [];
          this.popularCourses.forEach(c => {
            let courseModel = {
              title: c.courseModel.name.substr(0, 50) + '...',
              subtitle: c.courseModel.description,
              photo: c.courseModel && c.courseModel.pictureLarge ? this.baseURL + '/' + c.courseModel.pictureLarge : '/images/post.jpg',
              value: 1,
              price: this.currencyFormat(c.courseModel.price) + " so'm",
              id: c.courseId,
              link: window.location.href + '' + 'detailed-page/' + c.courseId
            }
            this.list.push(courseModel);
          })
        }
      })
    },
  },
  mounted() {
    this.getTopCourses();
  }
}
</script>

<style scoped>

</style>
