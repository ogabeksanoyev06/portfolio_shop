<template>
  <section class="section science-categories py-40"
  >
    <AppSlider :list="scienceCategories">
      <template #default="{item}">
        <router-link to="/"
                     class="app-card"
        >
          <div class="app-card__photo">
            <img :src="item.photo" :alt="item.title">
          </div>
          <div class="app-card__content">
            <app-text
              size="20"
              class="app-card__title"
              max-lines="1"
              line-height="27"
              weight="500"
              tag="h3"
            >
              {{ item.title }}
            </app-text>
          </div>

        </router-link>
      </template>
    </AppSlider>

  </section>
</template>

<script>
import AppSlider from "../../shared-components/AppSlider";
import {mapActions, mapGetters} from "vuex";

export default {
  name: "ScienceCategories",
  components: {
    AppSlider,
  },
  data() {
    return {
      scienceCategories: [
        {
          title: "Web Development",
          photo: "/icons/webDevelopment.svg",

        }
      ],
      icons: [
        '/icons/webDevelopment.svg',
        '/icons/economics.svg',
        '/icons/sciences.svg',
        '/icons/graphicDesign.svg'
      ]
    }
  },
  computed: {
    ...mapGetters(['skillTree']),
  },
  methods: {
    ...mapActions(['getSkillTree']),
    prepareModel() {
      this.scienceCategories = [];
      this.skillTree.forEach(s => {
        let model = {
          title: s.name,
          photo: this.icons[Math.floor(Math.random() * this.icons.length)]
        };
        this.scienceCategories.push(model);
      })
    },
  },
  mounted() {
    this.prepareModel();
  },
  created() {
    this.getSkillTree();
  },
  watch: {
    skillTree() {
      this.prepareModel();
    }
  }
}
</script>

<style lang="scss">

.science-categories {
  .app-card__content {
    min-height: auto;
  }
}


</style>
