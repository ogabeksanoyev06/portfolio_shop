<template>
  <kinesis-container>
    <div class="hero-banner">
      <div class="container">
        <div class="hero-banner__inner">
          <div class="hero-banner__content">
            <h1 class="hero-banner__title mb-20">
              <span class="color-main">Miraman</span> Education
            </h1>


            <app-text
                size="18"
                line-height="26"
                max-lines="2"
                weight="400"
                class="color-text mb-40"
            >
              Kasbiy maqsadlaringizga erishish uchun eng so'nggi ko'nikmalarni o'rganing.
            </app-text>

            <div class="hero-banner__cta">
              <base-input v-model="search" :placeholder="'Nimani o\'rganmoqchisiz ?'">
                <template #append>
                  <app-button theme="main" :sides="isMobile ? 20 : 50" radius="28">Qidirish</app-button>
                </template>
              </base-input>
            </div>

          </div>
          <div class="hero-banner__photo">
            <kinesis-element class="layer" :strength="10">
              <img src="/images/hero-banner.png" alt="">
            </kinesis-element>
          </div>

        </div>
      </div>
    </div>
  </kinesis-container>

</template>

<script>
import BaseInput from "../../shared-components/BaseInput";
import AppButton from "../../shared-components/AppButton";
import {KinesisContainer, KinesisElement} from 'vue-kinesis'

export default {
  name: "HeroBanner",
  components: {'kinesis-container': KinesisContainer, 'kinesis-element': KinesisElement, AppButton, BaseInput},
  data() {
    return {
      search: ''
    }
  }
}
</script>

<style lang="scss">
.hero-banner {
  background-color: #E7EEF5;

  &__inner {
    display: flex;
    align-items: center;
    justify-content: space-between;
    min-height: calc(100vh - 120px);
    width: 100%;

  }

  &__title {
    font-weight: 700;
    font-size: 42px;
    line-height: 51px;
  }

  &__content {
    max-width: calc(50% - 20px);
  }

  &__photo {
    max-width: calc(50% - 20px);
    padding: 20px;

    img {
      max-width: 530px;
      width: 100%;
      object-fit: contain;
      margin-left: auto;
    }
  }

  &__cta {
    max-width: 500px;
    width: 100%;
    overflow: hidden;
    padding: 5px 0;

    .input__block {

      &-wrap {
        border-color: transparent;
        border-radius: 28px !important;
      }

      &-input {
        border-radius: 28px !important;
        border-top-right-radius: 0 !important;
        border-bottom-right-radius: 0 !important;
        padding-right: 35px !important;
        padding-left: 20px !important;
        height: 56px;
      }

      &-append {
        position: relative;
        left: -20px;
      }
    }

    .a-btn {
      min-height: 56px;
    }
  }
}

@media (max-width: 850px) {
  .hero-banner__inner {
    flex-wrap: wrap;
    padding: 50px 30px;
    justify-content: unset;
  }

  .hero-banner__content {
    max-width: 100%;
    text-align: center;
    margin-left: auto;
    margin-right: auto;
    order: 2;
  }

  .hero-banner__cta {
    margin-left: auto;
    margin-right: auto;
  }

  .hero-banner__photo {
    margin-left: auto;
    margin-right: auto;
    order: 1;
    max-width: 80%;
    margin-bottom: 20px;
  }

  @media (max-width: 500px) {
    .hero-banner__inner {
      padding: 30px 10px;
    }

    .hero-banner__photo {
      margin-bottom: 10px;
    }
  }


}

@media (max-width: 500px) {
  .hero-banner__inner {
    min-height: calc(100vh - 90px);
  }

  .hero-banner__photo {
    margin-bottom: 0;
  }
}

</style>
