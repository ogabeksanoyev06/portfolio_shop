<template>
  <section class="section py-40">

    <div class="section__top mb-30">
      <AppText
          :size="isMobile ? 24 : 30"
          :line-height="isMobile ? 28 : 36"
          weight="700"
      >
        Yangi kurslar
      </AppText>

      <div class="section__top-details">
        <router-link class="section__top-link" to="/">
          Barchasi
        </router-link>
      </div>
    </div>

    <AppSlider :list="list">

      <template #default="{item, medium}">
        <AppCard
            :link="item.link"
            :title="item.title"
            :subtitle="item.subtitle"
            :photo="item.photo"
            :medium="medium"
            :id="item.id"
            :value="item.value"
            :price="item.price"
        />
      </template>


    </AppSlider>
  </section>
</template>

<script>
import AppSlider from "../../shared-components/AppSlider";
import AppCard from "../../shared-components/AppCard";

export default {
  name: "NewCourses",
  components: {AppCard, AppSlider},
  data() {
    return {
      list: [
        {
          title: "The Web Developer Bootcamp 2021",
          subtitle: "COMPLETELY REDONE - The only course you need to learn web development - HTML, CSS, JS, Node, and More!",
          photo: "/images/post.jpg",
          value: "2",
          price: "700 000 so'm"
        },
      ],
      newCourses: []
    }
  },
  methods: {
    getNewCourses() {
      this.$api.get('Main/Course/NewList').then(res => {
        if (!res.error) {
          this.newCourses = res.result.data;
          this.list = [];
          this.newCourses.forEach(c => {
            let courseModel = {
              title: c.name.substr(0, 50) + '...',
              subtitle: c.description,
              photo: c && c.pictureLarge ? this.baseURL + '/' + c.pictureLarge : '/images/post.jpg',
              value: 1,
              price: this.currencyFormat(c.price) + " so'm",
              id: c.id,
              link: window.location.href + '' + 'detailed-page/' + c.id
            }
            this.list.push(courseModel);
          })
        }
      })
    },
  },
  mounted() {
    this.getNewCourses();
  }
}
</script>

<style scoped>

</style>
