export default {
	TYPE_ONLINE: 'online',
	TYPE_BLOCK: 'block',
	TYPE_SCHOOL: 'school'
}
